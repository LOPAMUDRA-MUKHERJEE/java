import java.io.File;
import java.io.FileReader;

import java.io.FileWriter;
import java.io.IOException;

import java.util.Arrays;
import java.util.Scanner;

class binaryMultiplicationFast extends binaryOperations {
	@Override
	public myBinaryNumber binaryMultiplication(myBinaryNumber num_1, myBinaryNumber num_2) {
		int n = Math.max(num_1.getSize(), num_2.getSize());

		if (n <= 4) {
			binaryOperations operations = new binaryMultiplicationNaive();
			return operations.binaryMultiplication(num_1, num_2);
		}

		int mid = n / 2;

        // Split the numbers into high and low parts
        myBinaryNumber xHigh = num_1.getHighHalf(mid);
        myBinaryNumber xLow = num_1.getLowHalf(mid);

        myBinaryNumber yHigh = num_2.getHighHalf(mid);
        myBinaryNumber yLow = num_2.getLowHalf(mid);

        // Recursively compute the three products
        myBinaryNumber z0 = binaryMultiplication(xLow, yLow);
        myBinaryNumber z2 = binaryMultiplication(xHigh, yHigh);

		if (z2.getSize() == 0 || xHigh.getSize() == 0 || yHigh.getSize() == 0) {
           return new myBinaryNumber(1);
		}

        // Compute z1 = (xHigh + xLow) * (yHigh + yLow) - z0 - z2
        myBinaryNumber xSum = binaryAddition(xHigh, xLow);
        myBinaryNumber ySum = binaryAddition(yHigh, yLow);

        // Check if the size of xSum, ySum, or z1 becomes zero, and handle it
        if (xSum.getSize() == 0 || ySum.getSize() == 0) {
            return new myBinaryNumber(1); // Return a binary number with size 1 and value 0
        }

        myBinaryNumber z1 = binaryMultiplication(xSum, ySum);

		if(z1.getSize() == 0) {
            return new myBinaryNumber(1); // Return a binary number with size 1 and value 0
		}

        // Check if the size of z1 becomes zero, and handle it
        if (z1.getSize() == 0) {
            return new myBinaryNumber(1); // Return a binary number with size 1 and value 0
        }

        z1 = binarySubtraction(z1, z0);
        z1 = binarySubtraction(z1, z2);

        // Check if the size of z1 becomes zero after subtraction, and handle it
        if (z1.getSize() == 0) {
            return new myBinaryNumber(1); // Return a binary number with size 1 and value 0
        }


        // Compute the result using the formula: z2 * 2^n + z1 * 2^(n/2) + z0
        myBinaryNumber result = z2.shiftLeft(2 * mid);
        result = binaryAddition(result, z1.shiftLeft(mid));
        result = binaryAddition(result, z0);

        return result;
	}
}

class binaryMultiplicationNaive extends binaryOperations {
    @Override
    public myBinaryNumber binaryMultiplication(myBinaryNumber a, myBinaryNumber b) {
        int maxSize = a.getSize() + b.getSize();
        myBinaryNumber result = new myBinaryNumber(maxSize);

        for (int i = a.getSize() - 1; i >= 0; i--) {
            myBinaryNumber partialProduct = new myBinaryNumber(maxSize);
            int carry = 0;

            for (int j = b.getSize() - 1; j >= 0; j--) {
				int product = a.getBit(i) * b.getBit(j);
				carry += product / 2;
				product %= 2;

                partialProduct.setBit(i + j, product);
            }

            if (carry > 0)
                partialProduct.setBit(i, carry);

            result = binaryAddition(result, partialProduct);
        }

		result.truncateLeadingZeroes();

        return result;
    }
}


abstract class binaryOperations {
	public abstract myBinaryNumber binaryMultiplication(myBinaryNumber a, myBinaryNumber b);

	// Assuming num_1 >= num_2
	public myBinaryNumber binarySubtraction(myBinaryNumber num_1, myBinaryNumber num_2) {
        myBinaryNumber result = new myBinaryNumber(num_1.getSize());
        int borrow = 0;

        for (int i = num_1.getSize() - 1; i >= 0; i--) {
            int diff = num_1.getBit(i) - borrow - (i < num_2.getSize() ? num_2.getBit(i) : 0);
            if (diff < 0) {
                diff += 2;
                borrow = 1;
            } else
                borrow = 0;

            result.setBit(i, diff);
        }

        result.truncateLeadingZeroes();
        return result;
    }

	public myBinaryNumber binaryAddition(myBinaryNumber a, myBinaryNumber b) {
		myBinaryNumber larger, smaller;

		if (a.getSize() >= b.getSize()) {
    	    larger = a;
    	    smaller = b;
    	} else {
    	    larger = b;
    	    smaller = a;
    	}

		myBinaryNumber paddedSmaller = new myBinaryNumber(larger.getSize());
    	for (int i = 0; i < smaller.getSize(); i++) {
    	    paddedSmaller.setBit(i, smaller.getBit(i));
    	}

    	myBinaryNumber result = new myBinaryNumber(larger.getSize() + 1);
    	int carry = 0;

    	for (int i = 0; i < larger.getSize(); i++) {
    	    int sum = larger.getBit(i) + paddedSmaller.getBit(i) + carry;
    	    result.setBit(i, sum % 2);
    	    carry = sum / 2;
    	}

		if (carry == 1) {
			result.setBit(result.getSize() - 1, 1);
		}

		result.truncateLeadingZeroes();

    	return result;
	}
}

class myBinaryNumber {
	private int[] bits;

	public myBinaryNumber(int n) {
		if (n <= 0) {
			throw new IllegalArgumentException("Invalid bit width provided!");
		}

		this.bits = new int[n];
		Arrays.fill(this.bits, 0);
	}

	public myBinaryNumber(String S) {
		if (!S.matches("[01]+"))  { // Regular expression to match any permutation and combination of 0 & 1 occurring more than once
			throw new IllegalArgumentException("Invalid binary string format provided!");
		}

		this.bits = new int[S.length()];
		for (int i = 0; i < S.length(); i++) {
			if (S.charAt(i) == '1') {
				this.bits[i] = 1;
			} else {
				this.bits[i] = 0;
			}
		}
	}

	private void checkIndexInRange(int p) {
		if (p < 0 || p >= this.getSize()) {
			throw new IndexOutOfBoundsException("Bit index out of range!");
		}
	}

	public int getSize() {
		return this.bits.length;
	}

	public int getBit(int p) {
		checkIndexInRange(p);

		return this.bits[this.getSize() - 1 - p];
	}

	public void setBit(int p, int b) {
		checkIndexInRange(p);

		if (b != 0 && b != 1) {
			throw new IllegalArgumentException("Invalid bit value provided :(");
		}

		this.bits[this.getSize() - 1 - p] = b;
	}

	public void printNumber() {
		for (int i = 0; i < this.getSize(); i++) {
			System.out.print(this.bits[i]);
		}

		System.out.println();
	}

	public void printDecimalNumber() {
		int decimal = 0;
		int power = 1;

		for (int i = getSize() - 1; i >=0; i-- ) {
			if (this.bits[i] == 1) {
				decimal += power;
			}
			power *= 2;
		}
		System.out.println(decimal);
	}

	public void truncateLeadingZeroes() {
		int first_non_zero_idx = -1;

		for(int i = this.getSize() - 1; i >= 0; i--) {
			if (this.getBit(i) == 1) {
				first_non_zero_idx = i;
				break;
			}
		}

		int arr[] = new int[first_non_zero_idx + 1];

    	for (int i = 0; i <= first_non_zero_idx; i++) {
    	  arr[first_non_zero_idx - i] = this.getBit(i);
    	}

		this.bits = arr;
	}

	public myBinaryNumber getHighHalf(int length) {
		if (length >= this.getSize())
			return this;

		int start_idx = this.getSize() - length;
		myBinaryNumber result = new myBinaryNumber(length);

		for (int i = this.getSize() - 1; i >= start_idx; i--) {
			result.setBit(i - start_idx, this.getBit(i));
		}

		return result;
	}

    public myBinaryNumber getLowHalf(int length) {
        if (length >= this.getSize())
            return new myBinaryNumber(length);

		myBinaryNumber result = new myBinaryNumber(length);

		for (int i = 0; i < length; i++) {
			result.setBit(i, this.getBit(i));
		}

		return result;
    }

	public myBinaryNumber shiftLeft(int shift) {
		int new_size = this.getSize() + shift;
		myBinaryNumber result = new myBinaryNumber(new_size);

		for (int i = 0 ; i < this.getSize(); i++) {
			result.setBit(i + shift, this.getBit(i));
		}

		return result;
	}
}

class Driver {
    public static void main(String[] args) throws IOException {
		String binaryNumber1, binaryNumber2;

		File input_file = new File("input.txt");
		File output_file = new File("output.txt");
		File time_profiler = new File("time_profiler.txt");

        try (Scanner scanner = new Scanner(new FileReader(input_file));
             FileWriter output_writer = new FileWriter(output_file);
			 FileWriter time_profiler_writer = new FileWriter(time_profiler)) {

			while(true) {
				try {
					binaryNumber1 = scanner.nextLine();
					binaryNumber2 = scanner.nextLine();
				} catch (Exception ignore) {
					break;
				}


				myBinaryNumber num1 = new myBinaryNumber(binaryNumber1);
				myBinaryNumber num2 = new myBinaryNumber(binaryNumber2);

				/* binaryOperations operations = new binaryMultiplicationNaive(); */
				binaryOperations operations = new binaryMultiplicationFast();

				myBinaryNumber sum = operations.binaryAddition(num1, num2);

				long start_time = System.nanoTime();
				myBinaryNumber product = operations.binaryMultiplication(num1, num2);
				long end_time = System.nanoTime();

				long execution_time = (end_time - start_time);

				time_profiler_writer.write(execution_time + "");
				time_profiler_writer.write("\n");

				for (int i = sum.getSize() - 1; i >= 0; i--) {
					output_writer.write(sum.getBit(i) + "");
				}
				output_writer.write("\n");

				for (int i = product.getSize() - 1; i >= 0; i--) {
					output_writer.write(product.getBit(i) + "");
				}
				output_writer.write("\n");
			}
        } catch (IOException e) {
            System.out.println("Error reading or writing files: " + e.getMessage());
        }
    }
}
