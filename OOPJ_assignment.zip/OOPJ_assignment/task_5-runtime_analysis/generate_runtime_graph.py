#!/bin/python3

# This script is used to generate large inputs for plotting the quadratic growth
import os
import matplotlib.pyplot as plt

with open("../input.txt", "w") as file:
    for i in range(10, 1010, 10):
        file.write(bin(i)[2:] + '\n')
        file.write(bin(i)[2:] + '\n')

os.system('cd ../; javac Main.java; java Driver')

with open("../time_profiler.txt", "r") as file:
    lines = file.read().split()
    for i in range(len(lines)):
        lines[i] = int(lines[i]) # Convert binary ints to their decimal format for plotting

indices = range(len(lines))

plt.plot(indices, lines)
plt.title("Time growth of function call")
plt.show()

# with open("../output.txt", "r") as file:
#     lines = file.read().split()
#     lines = [lines[i] for i in range(len(lines)) if i % 2 != 0] # Ignore the sum lines, we only want the odd indices, AKA the product lines
# 
#     for i in range(len(lines)):
#         lines[i] = int(lines[i], 2) # Convert binary ints to their decimal format for plotting
# 
# indices = range(len(lines))
# plt.plot(indices, lines)
# 
# plt.title("Runtime")
# plt.show()
# 
