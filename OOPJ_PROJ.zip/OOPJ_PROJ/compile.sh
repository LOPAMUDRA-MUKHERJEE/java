#!/bin/sh

ant -Dplatforms.JDK_1.8.home=/usr/lib/jvm/java-21-openjdk-amd64/ compile
